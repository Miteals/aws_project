import boto3
import os
import sys
import uuid
from PIL import Image
import PIL.Image

IMAGE_WIDTH = os.getenv('IMAGE_WIDTH', 256)
IMAGE_HEIGHT = os.getenv('IMAGE_HEIGHT', 256)
IMAGE_SIZE = (IMAGE_WIDTH, IMAGE_HEIGHT)
S3_PREFIX = f"{IMAGE_WIDTH}x{IMAGE_HEIGHT}"
DYNAMODB_TABLE_NAME = os.getenv('DYNAMODB_TABLE_NAME', 256)
     
s3_client = boto3.client('s3')
dynamodb_client = boto3.client("dynamodb")
dynamodb = boto3.resource('dynamodb')

     
def resize_image(image_path, resized_path):
    with Image.open(image_path) as image:
        image.thumbnail(IMAGE_SIZE)
        image.save(resized_path)

def add_record_to_db(key):
    response = dynamodb_client.put_item(
        TableName=DYNAMODB_TABLE_NAME,
        Item={
            "name": {"S": key},
        },
    )
    print(response)
     
def handler(event, context):
    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key'] 
        download_path = '/tmp/{}{}'.format(uuid.uuid4(), key)
        upload_path = '/tmp/resized-{}'.format(key)
        
        s3_client.download_file(bucket, key, download_path)
        resize_image(download_path, upload_path)
        s3_client.upload_file(upload_path, '{}-resized'.format(bucket), f"{S3_PREFIX}/{key}")
        add_record_to_db(key)
        
def list_handler(event, context):
    table = dynamodb.Table(DYNAMODB_TABLE_NAME)

    response = table.scan()
    data = response['Items']

    while 'LastEvaluatedKey' in response:
       response = table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
       data.extend(response['Items'])
    
    return data



